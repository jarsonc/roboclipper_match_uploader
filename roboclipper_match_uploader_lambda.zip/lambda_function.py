import json
import boto3
import os

s3_client = boto3.client('s3')
print('Loading function')

notVideoFile = {
    'statusCode': 200,
    'body': json.dumps('Non-video file found!')
}

def lambda_handler(event, context):
    print(event)
    message = event['Records'][0]['Sns']['Message']
    print(type(message))
    print("From SNS: " + message)
    message = json.loads(message)
    bucketName = message["Records"][0]["s3"]["bucket"]["name"]
    bucketKey = message["Records"][0]["s3"]["object"]["key"]
    print(bucketName)
    print(bucketKey)
    if ".mp4" not in bucketKey:
        return notVideoFile
    try:        
        object = s3_client.get_object(Bucket=bucketName, Key=bucketKey)
        print(object)
        

    except Exception as err:
        print(err)
        
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }